# TitleRank

## 基于纯标题的新闻排序法
该算法包主要包含三个模块：
* 基于Word-weight的新闻排序法
* 基于Weight-PageRank的新闻排序法
* 基于相似文章的新闻排序法